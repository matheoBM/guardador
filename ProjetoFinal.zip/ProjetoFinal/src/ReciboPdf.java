
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author matheo
 */
public class ReciboPdf {
    
    private PDDocument pdDoc;
    private String nome;
    private String cpf;
    private String marca;
    private String modelo;
    private String cor;
    private String renavam;
    private String inicio;
    private String fim;
    private String preco;
    
    public ReciboPdf(String nome, String cpf, String marca,String modelo, String cor, String renavam,Date inicio, Date fim, double preco){
        this.nome = nome;
        this.cpf = cpf;
        
        this.marca = marca;
        this.modelo = modelo;       
        this.cor = cor;
        this.renavam = renavam;
        this.inicio = new SimpleDateFormat("dd/MM/yyyy").format(inicio);
        this.fim = new SimpleDateFormat("dd/MM/yyyy").format(fim);
        this.preco = Double.toString(preco);
        escreveRecibo();
        
    }
       
    
    
    public void escreveRecibo(){
        try{
            pdDoc = new PDDocument();
            PDPage pagina = new PDPage();
            pdDoc.addPage(pagina);
            PDPageContentStream pcs = new PDPageContentStream(pdDoc, pagina);
            
            pcs.beginText();
            pcs.setFont(PDType1Font.HELVETICA, 26);
            pcs.moveTextPositionByAmount(250, 750);
            pcs.drawString("Recibo");
            pcs.endText();
            
            pcs.beginText();
            pcs.setFont(PDType1Font.HELVETICA, 14);
            pcs.moveTextPositionByAmount(40, 680);
            pcs.drawString("Data: " + fim);
            pcs.endText();
            
            pcs.beginText();
            pcs.setFont(PDType1Font.HELVETICA, 14);
            pcs.moveTextPositionByAmount(40, 660);
            pcs.drawString("Locatário: "+ nome +", CPF: "+ cpf);
            pcs.endText();
            
            pcs.beginText();
            pcs.setFont(PDType1Font.HELVETICA, 14);
            pcs.moveTextPositionByAmount(40, 640);
            pcs.drawString("Carro " + marca + " "+ modelo + " da cor "+ cor + " e renavam " + renavam + "."); 
            pcs.endText();
            
            pcs.beginText();
            pcs.setFont(PDType1Font.HELVETICA, 14);
            pcs.moveTextPositionByAmount(40, 620);
            pcs.drawString("Alugado pelo período de "+ inicio + " a "+ fim);
            pcs.endText();
            
            pcs.beginText();
            pcs.setFont(PDType1Font.HELVETICA, 14);
            pcs.moveTextPositionByAmount(40, 600);
            pcs.drawString("Total a pagar: R$"+ preco );
            pcs.endText();
            
            pcs.close();
            pdDoc.save("recibo.pdf");
            pdDoc.close();
            
        }catch(IOException ioe){
            System.err.println(ioe);
        }
    }
}
