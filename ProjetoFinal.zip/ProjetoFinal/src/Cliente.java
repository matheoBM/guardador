
import java.io.Serializable;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Luan
 */
public class Cliente extends Pessoa implements Serializable{

    private String endereco;
    private int nroAlugueis;
    private String email;
    private boolean alugado;

    public Cliente(String nome, String telefone, String documento, String dataNasc, String sexo, String email, String endereco) {
        super(nome, telefone, documento, dataNasc, sexo);
        this.endereco = endereco;
        this.email = email;
    }

    /**
     * @return the nroAlugueis
     */
    public int getNroAlugueis() {
        return nroAlugueis;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }
    
    public String getAluguel(){
        if(alugado == false){
            return "Nenhum";
        }else{
            return "Em aberto";
        }
    }

    /**
     * @return the alugado
     */
    public void setAluguel() {
        if(alugado){
            alugado = false;
        }else{
            alugado = true;
        }
    }

}
