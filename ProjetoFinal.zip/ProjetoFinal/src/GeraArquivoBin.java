


import java.io.*;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Luan
 */
public abstract class GeraArquivoBin {
    
    protected static void geraCarros()
    {
        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("Carros.bin"));
            oos.writeInt(ListaCarros.listaCarros.size());
            
            for (int i = 0; i < ListaCarros.listaCarros.size(); i++)
            {
                oos.writeObject(ListaCarros.listaCarros.get(i));
            }
                
            oos.close();
        } catch (FileNotFoundException fnfe) {
        } catch (IOException ioe) {
        }
    }
    
    protected static void geraFuncionario()
    {
        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("Funcionarios.bin"));
            oos.writeInt(1);
            oos.writeInt(ListaFuncionarios.listaFuncionarios.size());
            
            for (int i = 0; i < ListaFuncionarios.listaFuncionarios.size(); i++)
            {
                oos.writeObject(ListaFuncionarios.listaFuncionarios.get(i));
            }
                
            oos.close();
        } catch (FileNotFoundException fnfe) {
        } catch (IOException ioe) {
        }
    }
    
    protected static void geraCliente()
    {
        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("Clientes.bin"));
            oos.writeInt(ListaClientes.listaClientes.size());
            
            for (int i = 0; i < ListaClientes.listaClientes.size(); i++)
            {
                oos.writeObject(ListaClientes.listaClientes.get(i));
            }
                
            oos.close();
        } catch (FileNotFoundException fnfe) {
        } catch (IOException ioe) {
        }
    }
    
    protected static void geraAluguel()
    {
        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("Alugueis.bin"));
            oos.writeInt(ListaAlugueis.listaAlugueis.size());
            
            for (int i = 0; i < ListaAlugueis.listaAlugueis.size(); i++)
            {
                oos.writeObject(ListaAlugueis.listaAlugueis.get(i));
            }  
            oos.close();
        } catch (FileNotFoundException fnfe) {
        } catch (IOException ioe) {
        }
    }   
}