
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;


/**
 *
 * @author matheo
 */
public class AlugueisClasse implements Serializable {
    
    Carro carro;
    Cliente cliente;
    Date diaAluguel;
    Date devolucao;
    
    public AlugueisClasse(Carro carro, Cliente cliente, Date diaAluguel, Date devolucao){
        this.carro = carro;
        this.cliente = cliente;
        this.diaAluguel = diaAluguel;
        this.devolucao = devolucao;
    }
    
    public String getMarca(){
        return carro.getMarca();
    }
    public String getModelo(){
        return carro.getModelo();
    }
    public String getCor(){
        return carro.getCor();
    }   
    public String getRenavam(){
        return carro.getRenavam();
    }
    public int getDiasMinimos(){
        return carro.getDiasMinimos();
    }
    public double getPreco(){
        return carro.getPrecoDiario();
    }
    public double getMulta(){
        return carro.getMultaDiaria();
    }
    
    
    public String getNome(){
        return cliente.getNome();
    }
    public String getDocumento(){
        return cliente.getDocumento();
    }
    
    public Date getData(){
        
        return diaAluguel;
    }
    public Date getDevolucao(){
        
        return devolucao;
    }
    
    
}
