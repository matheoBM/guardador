
import java.io.Serializable;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Luan
 */
public abstract class Pessoa implements Serializable{
    private String nome;
    private String telefone;
    private String documento;
    private String dataNascimento;
    private String sexo;
        
    public Pessoa(String nome, String telefone, String documento, String dataNasc, String sexo)
    {
        this.nome = nome;
        this.telefone = telefone;
        this.documento = documento;
        this.dataNascimento = dataNasc;
        this.sexo = sexo;
    }
 
    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @return the telefone
     */
    public String getTelefone() {
        return telefone;
    }

    /**
     * @return the documento
     */
    public String getDocumento() {
        return documento;
    }

    /**
     * @return the dataNascimento
     */
    public String getDataNascimento() {
        return dataNascimento;
    }
}
