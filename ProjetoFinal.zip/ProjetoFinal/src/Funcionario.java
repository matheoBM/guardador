
import java.io.Serializable;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Luan
 */
public class Funcionario extends Pessoa implements Serializable{

    /**
     * @return the senha
     */
    public String getSenha() {
        return senha;
    }

    /**
     * @return the login
     */
    public String getLogin() {
        return login;
    }
   
   private String senha;
   private String login;
      
   public Funcionario(String nome, String telefone, String documento, String dataNasc, String sexo, String login, String senha)
   {
       super(nome,  telefone, documento, dataNasc, sexo);
       this.login = login;
       this.senha = senha;
   }        
}
