
import java.io.Serializable;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Luan
 */
public class Carro implements Serializable{
    
    private String marca;
    private String modelo;
    private String cor;
    private String renavam;
    private int diasMinimos;
    private double precoDiario;
    private double multaDiaria;
    private boolean alugado = false;
    
    public Carro(String marca, String modelo, String cor, String renavam, int diasMinimos, double precoDiario, double multaDiaria)
    {
        this.marca = marca;
        this.modelo = modelo;
        this.cor = cor;
        this.renavam = renavam;
        this.precoDiario = precoDiario;
        this.diasMinimos = diasMinimos;
        this.multaDiaria = multaDiaria;
    }

    /**
     * @return the marca
     */
    public String getMarca() {
        return marca;
    }

    /**
     * @return the modelo
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * @return the cor
     */
    public String getCor() {
        return cor;
    }

    /**
     * @return the renavam
     */
    public String getRenavam() {
        return renavam;
    }

    /**
     * @return the diasMinimos
     */
    public int getDiasMinimos() {
        return diasMinimos;
    }

    /**
     * @return the precoDiario
     */
    public double getPrecoDiario() {
        return precoDiario;
    }

    /**
     * @return the multaDiaria
     */
    public double getMultaDiaria() {
        return multaDiaria;
    }

    /**
     * @return the alugado
     */
    public boolean isAlugado() {
        return alugado;
    }

    void setDiasMinimos(int dias) {
        this.diasMinimos = dias;
    }

    void setPreco(double preco) {
        this.precoDiario = preco;
    }

    void setMulta(double multa) {
        this.multaDiaria = multa;
    }
    
    //como so pode ser true ou false, quando vc chama o metodo ele muda para o oposto
    void setIsAlugado(){
        if(alugado){
            alugado = false;
        }else{
            alugado = true;
        }
    }
}
